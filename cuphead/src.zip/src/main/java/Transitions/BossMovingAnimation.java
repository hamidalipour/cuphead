package Transitions;

import application.App;
import controllers.GameController;
import javafx.animation.Transition;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import models.GameNet;
import views.Components.Bomb;
import views.Components.Boss;
import views.Components.Bullet;

import java.util.Objects;
import java.util.Random;

import static java.lang.Math.floor;

public class BossMovingAnimation extends Transition {

    private Boss boss;
    private AnchorPane anchorPane;

    public BossMovingAnimation(Boss boss, AnchorPane anchorPane){
        this.boss = boss;
        this.anchorPane = anchorPane;
        this.setCycleDuration(Duration.millis(1000));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate(double v) {
        if (boss.isExploded()){
            wasExploded(v);
        } else {
            updatePosition(v);

            for (Node child : anchorPane.getChildren()) {
                if ((child instanceof Bullet) && !((Bullet) child).isHurtTheEnemy() && GameController.haveCollision((Rectangle) child, boss)){
                    boss.setHealth(boss.getHealth() - GameNet.getCurrentGame().getAttackStrength());
                    GameNet.getCurrentGame().setBossFinalHealth(boss.getHealth());
                    ((Bullet) child).setHurtTheEnemy(true);
                    if (boss.getHealth() <= 0){
                        boss.setExploded(true);
                        this.playFromStart();

                    }
                } else if (child instanceof Bomb && !((Bomb) child).isHurtTheEnemy() && GameController.haveCollision((Rectangle) child, boss)){
                    boss.setHealth(boss.getHealth() - 2 * GameNet.getCurrentGame().getAttackStrength());
                    GameNet.getCurrentGame().setBossFinalHealth(boss.getHealth());
                    ((Bomb) child).setHurtTheEnemy(true);
                    if (boss.getHealth() <= 0){
                        boss.setExploded(true);
                        this.playFromStart();

                    }
                }
            }

        }
    }

    private void wasExploded(double v) {
        this.stop();
        App.changeMenu("EndGamePage");
    }

    public void updatePosition(double v){
        if (boss.isMovingUp()){
            if (boss.getY() > 10){
                boss.setY(boss.getY() - 1);
            } else boss.setMovingUp(false);
        } else {
            if (boss.getY() < 300){
                boss.setY(boss.getY() + 1);
            } else boss.setMovingUp(true);
        }


        if (v != 1){
            Image image;

            if (boss.isShooting()){
                if (v > 0.5 && !boss.isBulletWasShot()){
                    boss.setBulletReadyToBeShot(true);
                    boss.setBulletWasShot(true);
                }
                double v12 = v * 12;
                int index = (int) (floor(v12) + 1);

                image = new Image(
                        Objects.requireNonNull(getClass().getResource(
                                "/images/BossShoot/" + index + ".png")).toExternalForm());

            } else {
                double v6 = v * 6;
                int index = (int) (floor(v6) + 1);

                image = new Image(
                        Objects.requireNonNull(getClass().getResource(
                                "/images/BossFly/" + index + ".png")).toExternalForm());
            }

            boss.setImagePattern(GameController.checkForGrayscaleOfImage(image));

        } else {
            if (boss.isShooting()){
                boss.setShooting(false);
            } else {
                Random random = new Random();
                if (random.nextInt(5) == 0){
                    boss.setShooting(true);
                    boss.setBulletWasShot(false);
                }
            }
        }
    }
}
