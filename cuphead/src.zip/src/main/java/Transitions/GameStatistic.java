package Transitions;

import javafx.animation.Transition;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;
import models.Game;
import models.GameNet;
import views.Components.Boss;
import views.Components.CupHead;

public class GameStatistic extends Transition {
    private Boss boss;
    private CupHead cupHead;
    private Text time;
    private Text cupHeadSore;
    private Text cupHeadHealth;
    private Text bossHealth;
    private ProgressBar bossHealthProgressBar;

    public GameStatistic(Boss boss, CupHead cupHead, Text time, Text cupHeadSore, Text cupHeadHealth, Text bossHealth, ProgressBar bossHealthProgressBar) {
        this.boss = boss;
        this.cupHead = cupHead;
        this.time = time;
        this.cupHeadSore = cupHeadSore;
        this.cupHeadHealth = cupHeadHealth;
        this.bossHealth = bossHealth;
        this.bossHealthProgressBar = bossHealthProgressBar;
        this.setCycleDuration(Duration.millis(1000));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate(double v) {
        if (v == 1) addOneSecondToTime();

        cupHeadSore.setText("score: " + GameNet.getCurrentGame().getScore());

        cupHeadHealth.setText("lives: " + GameNet.getCurrentGame().getHealth());
        if (GameNet.getCurrentGame().getHealth() <= 2) cupHeadHealth.setFill(Color.RED);

        bossHealth.setText("boss lives: " + boss.getHealth());

        bossHealthProgressBar.setProgress(boss.getHealth() / 300);
        if (boss.getHealth() < 50) bossHealthProgressBar.setStyle("-fx-accent: red");
    }

    public void addOneSecondToTime(){
        Game game = GameNet.getCurrentGame();

        if (game.getSecond() != 59) game.setSecond(game.getSecond() + 1);
        else if (game.getMinute() != 59) {
            game.setMinute(game.getMinute() + 1);
            game.setSecond(0);
        } else {
            game.setHour(game.getHour() + 1);
            game.setMinute(0);
            game.setSecond(0);
        }

        time.setText(GameNet.getCurrentGame().getHour() + ":" +
                GameNet.getCurrentGame().getMinute() + ":" + GameNet.getCurrentGame().getSecond());

    }
}
