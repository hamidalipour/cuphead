package Transitions;

import controllers.GameController;
import javafx.animation.Transition;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import models.GameNet;
import views.Components.*;

import java.util.Objects;

import static java.lang.Math.floor;

public class MiniBossAnimation extends Transition {
    private MiniBoss miniBoss;
    private AnchorPane anchorPane;

    public MiniBossAnimation(MiniBoss miniBoss, AnchorPane anchorPane){
        this.anchorPane = anchorPane;
        this.miniBoss = miniBoss;
        this.setCycleDuration(Duration.millis(500));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate(double v) {
        if (miniBoss.isExploded()){
            wasExploded(v);
        } else {
            checkBeingInsideBoard(v);
            updatePosition(v);

            for (Node child : anchorPane.getChildren()) {
                if ((child instanceof Bullet) && !((Bullet) child).isHurtTheEnemy() && GameController.haveCollision((Rectangle) child, miniBoss)){
                    miniBoss.setHealth(miniBoss.getHealth() - 1);
                    ((Bullet) child).setHurtTheEnemy(true);
                    if (miniBoss.getHealth() <= 0){
                        if (!GameNet.isMute()) GameNet.getExplosion().play();
                        miniBoss.setExploded(true);
                        this.playFromStart();

                    }
                } else if (child instanceof Bomb && !((Bomb) child).isHurtTheEnemy() && GameController.haveCollision((Rectangle) child, miniBoss)){
                    miniBoss.setExploded(true);
                    miniBoss.setHealth(0);
                    if (!GameNet.isMute()) GameNet.getExplosion().play();
                    ((Bomb) child).setHurtTheEnemy(true);
                    this.playFromStart();
                }
            }

        }




    }

    private void wasExploded(double v) {
        if (v == 1){
            anchorPane.getChildren().remove(miniBoss);
            this.stop();

        } else {
            double v11 = v * 11;
            int index = (int) (floor(v11) + 1);
            Image image;

            if (miniBoss.getNumber() == 4){
                image = new Image(
                        Objects.requireNonNull(getClass().getResource(
                                "/images/Flappy Birds/Pink/Death/flappy_bird_death_pink_000" + index + ".png")).toExternalForm());
            } else {
                image = new Image(
                        Objects.requireNonNull(getClass().getResource(
                                "/images/Flappy Birds/Yellow/Death/flappy_bird_death_000" + index + ".png")).toExternalForm());
            }

            miniBoss.setImagePattern(GameController.checkForGrayscaleOfImage(image));

        }
    }

    public void checkBeingInsideBoard(double v){
        if (v == 1 && miniBoss.getX() < -100){
            anchorPane.getChildren().remove(miniBoss);
            this.stop();
        }
    }

    public void updatePosition(double v){
        miniBoss.setX(miniBoss.getX() - 4);

        if (v != 1){

            double v4 = v * 4;
            int index = (int) (floor(v4) + 1);
            Image image;

            if (miniBoss.getNumber() == 4){
                image = new Image(
                        Objects.requireNonNull(getClass().getResource(
                                "/images/purple/" + index + ".png")).toExternalForm());
            } else {
                image = new Image(
                        Objects.requireNonNull(getClass().getResource(
                                "/images/yellow/" + index + ".png")).toExternalForm());
            }

            miniBoss.setImagePattern(GameController.checkForGrayscaleOfImage(image));


        }
    }
}
