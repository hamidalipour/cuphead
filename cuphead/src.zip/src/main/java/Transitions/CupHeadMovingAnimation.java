package Transitions;

import application.App;
import controllers.GameController;
import javafx.animation.Transition;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import models.GameNet;
import views.Components.Boss;
import views.Components.CupHead;
import views.Components.Egg;
import views.Components.MiniBoss;

import java.util.Objects;

import static java.lang.Math.ceil;
import static java.lang.Math.floor;

public class CupHeadMovingAnimation extends Transition {

    private CupHead cupHead;
    private AnchorPane anchorPane;

    public CupHeadMovingAnimation(CupHead cupHead, AnchorPane anchorPane) {
        this.cupHead = cupHead;
        this.anchorPane = anchorPane;
        this.setCycleDuration(Duration.millis(1500));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate(double v) {
        if (cupHead.isExploded()){
            wasExploded(v);
        } else {

            updatePosition(v);

            for (Node child : anchorPane.getChildren()) {
                if ((child instanceof Boss || child instanceof MiniBoss || child instanceof Egg) &&
                        GameController.haveCollision((Rectangle) cupHead, (Rectangle) child)){
                    if (!GameNet.isMute()) GameNet.getExplosion().play();
                    explode(child);
                    break;
                }
            }
        }
    }

    private void explode(Node child){
        cupHead.setExploded(true);
        GameNet.getCurrentGame().setHealth(GameNet.getCurrentGame().getHealth() - GameNet.getCurrentGame().getVulnerability());
        if (GameNet.getCurrentGame().getHealth() <= 0){
            this.stop();
            App.changeMenu("EndGamePage");
        }
        if (!(child instanceof Boss))
            anchorPane.getChildren().remove(child);
        this.playFromStart();
    }

    private void wasExploded(double v) {
        if (v == 1){
            cupHead.setExploded(false);
            Image image = new Image(
                    Objects.requireNonNull(getClass().getResource(
                            "/images/mugman_plane_idle_straight_0001.png")).toExternalForm());
            cupHead.setImagePattern(GameController.checkForGrayscaleOfImage(image));

        } else {
            double v11 = v * 11;
            int index = (int) (floor(v11) + 1);

            Image image = new Image(
                    Objects.requireNonNull(getClass().getResource(
                            "/images/mugman_plane_idle_straight_0001.png")).toExternalForm());
            if (index % 2 == 0){
                WritableImage writableImage = GameController.blinkImage(image);
                cupHead.setImagePattern(new ImagePattern(writableImage));
            } else {
                cupHead.setImagePattern(GameController.checkForGrayscaleOfImage(image));
            }
        }


    }




    public void updatePosition(double v){
        if (v != 1) {


            double v11 = v * 11;
            int index = (int) (floor(v11) + 1);
            Image image;

            if (cupHead.isTurned()){
                if (cupHead.isMovingDown()) {

                    image = new Image(
                            Objects.requireNonNull(getClass().getResource(
                                    "/images/cuphead_turning/down_11.png")).toExternalForm());

                } else if (cupHead.isMovingUp()) {

                    image = new Image(
                            Objects.requireNonNull(getClass().getResource(
                                    "/images/cuphead_turning/up_11.png")).toExternalForm());
                } else {
                    image = new Image(
                            Objects.requireNonNull(getClass().getResource(
                                    "/images/mugman_plane_idle_straight_0001.png")).toExternalForm());

                }
            } else {
                if (cupHead.isMovingDown()) {
                    image = new Image(
                            Objects.requireNonNull(getClass().getResource(
                                    "/images/cuphead_turning/down_" + index + ".png")).toExternalForm());

                } else if (cupHead.isMovingUp()) {
                    image = new Image(
                            Objects.requireNonNull(getClass().getResource(
                                    "/images/cuphead_turning/up_" + index + ".png")).toExternalForm());

                } else {
                    image = new Image(
                            Objects.requireNonNull(getClass().getResource(
                                    "/images/mugman_plane_idle_straight_0001.png")).toExternalForm());
                }
            }

            cupHead.setImagePattern(GameController.checkForGrayscaleOfImage(image));


        } else {
            cupHead.setTurned(true);
        }
    }


}
