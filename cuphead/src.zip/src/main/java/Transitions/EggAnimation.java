package Transitions;

import javafx.animation.Transition;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.ImagePattern;
import javafx.util.Duration;
import views.Components.Egg;

import java.util.Objects;

public class EggAnimation extends Transition {
    private final Egg egg;
    private AnchorPane anchorPane;

    public EggAnimation(Egg egg, AnchorPane anchorPane) {
        this.anchorPane = anchorPane;
        this.egg = egg;
        this.setCycleDuration(Duration.millis(500));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate(double v) {
        if (v == 1 && egg.getX() < -100){
            anchorPane.getChildren().remove(egg);
            this.stop();
        }
        egg.setX(egg.getX() - 4);
    }
}
