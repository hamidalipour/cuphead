package Transitions;

import javafx.animation.Transition;
import javafx.application.Platform;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import models.GameNet;
import views.Components.Boss;
import views.Components.Egg;
import views.Components.MiniBoss;

import java.util.Random;

public class BossAttackTimeline extends Transition {
    private AnchorPane anchorPane;
    private Boss boss;

    public BossAttackTimeline(AnchorPane anchorPane, Boss boss){
        this.anchorPane = anchorPane;
        this.boss = boss;
        this.setCycleDuration(Duration.millis(1000));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate(double v) {
        if (boss.isBulletReadyToBeShot()){
            boss.setBulletReadyToBeShot(false);
            Egg egg = new Egg((int) boss.getY() + 200);
            EggAnimation eggAnimation = new EggAnimation(egg, anchorPane);
            eggAnimation.play();
            GameNet.getCurrentGame().getGameTransitions().add(eggAnimation);
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    anchorPane.getChildren().add(2, egg);
                }
            });
        }

        Random random = new Random();
        int randomNumber = random.nextInt(20);
        if (v == 1){
            if (randomNumber == 0){
                MiniBoss miniBoss1 = new MiniBoss(true, 1);
                MiniBoss miniBoss2 = new MiniBoss(true, 2);
                MiniBoss miniBoss3 = new MiniBoss(true, 3);
                MiniBoss miniBoss4 = new MiniBoss(true, 4);
                generateNewMiniBosses(miniBoss1, miniBoss2, miniBoss3, miniBoss4);
            } else if (randomNumber == 1){
                MiniBoss miniBoss1 = new MiniBoss(false, 1);
                MiniBoss miniBoss2 = new MiniBoss(false, 2);
                MiniBoss miniBoss3 = new MiniBoss(false, 3);
                MiniBoss miniBoss4 = new MiniBoss(false, 4);
                generateNewMiniBosses(miniBoss1, miniBoss2, miniBoss3, miniBoss4);

            }

        }
    }

    public void generateNewMiniBosses(MiniBoss miniBoss1, MiniBoss miniBoss2, MiniBoss miniBoss3, MiniBoss miniBoss4){
        MiniBossAnimation miniBossAnimation1 = new MiniBossAnimation(miniBoss1, anchorPane);
        miniBossAnimation1.play();
        GameNet.getCurrentGame().getGameTransitions().add(miniBossAnimation1);
        MiniBossAnimation miniBossAnimation2 = new MiniBossAnimation(miniBoss2, anchorPane);
        miniBossAnimation2.play();
        GameNet.getCurrentGame().getGameTransitions().add(miniBossAnimation2);
        MiniBossAnimation miniBossAnimation3 = new MiniBossAnimation(miniBoss3, anchorPane);
        miniBossAnimation3.play();
        GameNet.getCurrentGame().getGameTransitions().add(miniBossAnimation3);
        MiniBossAnimation miniBossAnimation4 = new MiniBossAnimation(miniBoss4, anchorPane);
        miniBossAnimation4.play();
        GameNet.getCurrentGame().getGameTransitions().add(miniBossAnimation4);


        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                anchorPane.getChildren().add(miniBoss1);
                anchorPane.getChildren().add(miniBoss2);
                anchorPane.getChildren().add(miniBoss3);
                anchorPane.getChildren().add(miniBoss4);
            }
        });
    }
}
