package Transitions;

import controllers.GameController;
import javafx.animation.Transition;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import models.GameNet;
import views.Components.Boss;
import views.Components.Bullet;
import views.Components.Egg;
import views.Components.MiniBoss;

import java.util.Objects;

import static java.lang.Math.floor;

public class BulletAnimation extends Transition {
    private final Bullet bullet;
    private AnchorPane anchorPane;

    public BulletAnimation(Bullet bullet, AnchorPane anchorPane) {
        this.anchorPane = anchorPane;
        this.bullet = bullet;
        this.setCycleDuration(Duration.millis(500));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate(double v) {
        if (bullet.isExploded()){
            explode(v);
        } else {

            if (v == 1 && bullet.getX() > 1300){
                anchorPane.getChildren().remove(bullet);
                this.stop();
            }
            bullet.setX(bullet.getX() + 10);

            for (Node child : anchorPane.getChildren()) {
                if ((child instanceof Boss || child instanceof MiniBoss) && GameController.haveCollision((Rectangle) bullet, (Rectangle) child)){
                    bullet.setExploded(true);
                    GameNet.getCurrentGame().setScore(GameNet.getCurrentGame().getScore() + 1);
                    this.playFromStart();
                }
            }
        }


    }

    public void explode(double v){
        if (v != 1){
            double v12 = v * 12;
            int index = (int) (floor(v12) + 1);

            Image image = new Image(
                    Objects.requireNonNull(getClass().getResource(
                            "/images/Hit Dust/hit" + index + ".png")).toExternalForm());
            bullet.setImagePattern(GameController.checkForGrayscaleOfImage(image));
        } else {
            anchorPane.getChildren().remove(bullet);
            this.stop();
        }
    }


}
