package models;

import java.util.Random;

public class User {
    private String username;
    private String password;
    private double point = 0;
    private int avatar;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        Random random = new Random();
        this.avatar = random.nextInt(5);
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public double getPoint() {
        return point;
    }

    public int getAvatar() {
        return avatar;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPoint(double point) {
        this.point = point;
    }

    public void setAvatar(int avatar) {
        this.avatar = avatar;
    }
}
