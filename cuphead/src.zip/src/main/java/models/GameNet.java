package models;

import application.App;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.scene.image.Image;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class GameNet {
    private static ArrayList<User> users = new ArrayList<>();
    private static User currentUser = null;
    private static Game currentGame = null;
    private static int gameLevel = 2;
    private static boolean grayscale = false;
    private static boolean mute = false;
    private static AudioClip menuMusic;
    private static MediaPlayer gameMusic;
    private static AudioClip firingSound;
    private static AudioClip explosion;

    public static void initializeMusics(){
        menuMusic = new AudioClip(Objects.requireNonNull(App.class.getResource("/music/Menu_music.mp3")).toString());
        menuMusic.play();
        menuMusic.setCycleCount(AudioClip.INDEFINITE);

        Media media = new Media(Objects.requireNonNull(App.class.getResource("/music/Game_music.mp3")).toString());
        gameMusic = new MediaPlayer(media);
        gameMusic.setCycleCount(AudioClip.INDEFINITE);

        firingSound = new AudioClip(Objects.requireNonNull(App.class.getResource("/music/bullet_firing.mp3")).toString());

        explosion = new AudioClip(Objects.requireNonNull(App.class.getResource("/music/explosion.mp3")).toString());
    }

    public static void readAllUsers() throws IOException {
        String json = new String(Files.readAllBytes(Paths.get("./src/main/resources/usersData.json")));
        users = new Gson().fromJson(json,
                new TypeToken<List<User>>(){}.getType());
        if (users == null)
            users = new ArrayList<>();
    }

    public static void saveAllUsers() throws IOException {
        FileWriter fileWriter = new FileWriter("./src/main/resources/usersData.json");
        fileWriter.write(new Gson().toJson(users));
        fileWriter.close();
    }

    public static void sortUsers(){
        Collections.sort(users, new Comparator() {

            public int compare(Object o1, Object o2) {

                double x1 = ((User) o1).getPoint();
                double x2 = ((User) o2).getPoint();

                return Double.compare(x2, x1);
            }});
    }

    public static User getUserByUsername(String username){
        for (User user : users) {
            if (user.getUsername().equals(username)) return user;
        }
        return null;
    }

    public static void addUser(User user){
        users.add(user);
    }

    public static ArrayList<User> getUsers() {
        return users;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static int getGameLevel() {
        return gameLevel;
    }

    public static boolean isGrayscale() {
        return grayscale;
    }

    public static boolean isMute() {
        return mute;
    }

    public static AudioClip getMenuMusic() {
        return menuMusic;
    }

    public static MediaPlayer getGameMusic() {
        return gameMusic;
    }

    public static AudioClip getFiringSound() {
        return firingSound;
    }

    public static AudioClip getExplosion() {
        return explosion;
    }

    public static void setCurrentUser(User currentUser) {
        GameNet.currentUser = currentUser;
    }

    public static Game getCurrentGame() {
        return currentGame;
    }

    public static void setCurrentGame(Game currentGame) {
        GameNet.currentGame = currentGame;
    }

    public static void setGameLevel(int gameLevel) {
        GameNet.gameLevel = gameLevel;
    }

    public static void setGrayscale(boolean grayscale) {
        GameNet.grayscale = grayscale;
    }

    public static void setMute(boolean mute) {
        GameNet.mute = mute;
    }
}
