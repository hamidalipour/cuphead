package models;

import javafx.animation.Transition;

import java.util.ArrayList;

public class Game {
    private double health;
    private double vulnerability;
    private double attackStrength;
    private int gameLevel;
    private double score = 0;
    private double bossFinalHealth = 1000;
    private int second = 0;
    private int minute = 0;
    private int hour = 0;

    private ArrayList<Transition> gameTransitions = new ArrayList<>();

    private boolean shootingBullet = true;

    public Game(int level){
        if (level == 1){
            this.health = 10;
            this.vulnerability = 0.5;
            this.attackStrength = 1.5;
        } else if (level == 2){
            this.health = 5;
            this.vulnerability = 1;
            this.attackStrength = 1;
        } else {
            this.health = 2;
            this.vulnerability = 1.5;
            this.attackStrength = 0.5;
        }

        this.gameLevel = level;
    }

    public boolean isShootingBullet() {
        return shootingBullet;
    }

    public void setShootingBullet(boolean shootingBullet) {
        this.shootingBullet = shootingBullet;
    }

    public double getHealth() {
        return health;
    }

    public double getVulnerability() {
        return vulnerability;
    }

    public double getAttackStrength() {
        return attackStrength;
    }

    public double getScore() {
        return score;
    }

    public int getSecond() {
        return second;
    }

    public int getMinute() {
        return minute;
    }

    public int getHour() {
        return hour;
    }

    public double getBossFinalHealth() {
        return bossFinalHealth;
    }

    public int getGameLevel() {
        return gameLevel;
    }

    public ArrayList<Transition> getGameTransitions() {
        return gameTransitions;
    }

    public void setHealth(double health) {
        this.health = health;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public void setBossFinalHealth(double bossFinalHealth) {
        this.bossFinalHealth = bossFinalHealth;
    }

    public void setSecond(int second) {
        this.second = second;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }
}
