package views;

import application.App;
import controllers.MenuController;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Border;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import models.Game;
import models.GameNet;
import models.User;

import java.net.URL;
import java.util.Objects;

public class FirstPageController {

    @FXML
    private Text passwordHeader;
    @FXML
    private Text usernameHeader;
    @FXML
    private TextField username;
    @FXML
    private TextField password;

    public void initialize(){
        usernameHeader.setStyle("-fx-text-fill: red");
        passwordHeader.setStyle("-fx-text-fill: red");
    }

    public void signupUser(MouseEvent mouseEvent) {
        if (GameNet.getUserByUsername(username.getText()) != null){
            usernameHeader.setText("please enter a new username");
            passwordHeader.setText("");
            username.setStyle("-fx-border-color: red");
            password.setStyle("-fx-border-color: blue");
        }else if (MenuController.passwordIsWeak(password.getText())){
            usernameHeader.setText("");
            passwordHeader.setText("password is weak");
            username.setStyle("-fx-border-color: blue");
            password.setStyle("-fx-border-color: red");
        }else {
            usernameHeader.setText("");
            passwordHeader.setText("");
            username.setStyle("-fx-border-color: blue");
            password.setStyle("-fx-border-color: blue");
            User user = new User(username.getText(), password.getText());
            GameNet.addUser(user);
            GameNet.setCurrentUser(user);
            App.changeMenu("MainMenu");
        }
    }

    public void loginUser(MouseEvent mouseEvent) {
        User user;
        if ((user = GameNet.getUserByUsername(username.getText())) == null){
            usernameHeader.setText("no such a username");
            passwordHeader.setText("");
            username.setStyle("-fx-border-color: red");
            password.setStyle("-fx-border-color: blue");
        }else if (!user.getPassword().equals(password.getText())){
            usernameHeader.setText("");
            passwordHeader.setText("password is incorrect");
            username.setStyle("-fx-border-color: blue");
            password.setStyle("-fx-border-color: red");
        }else {
            usernameHeader.setText("");
            passwordHeader.setText("");
            username.setStyle("-fx-border-color: blue");
            password.setStyle("-fx-border-color: blue");
            GameNet.setCurrentUser(user);
            App.changeMenu("MainMenu");
        }
    }

    public void startGameAsGuest(MouseEvent mouseEvent) {
        Game game = new Game(2);
        GameNet.setCurrentGame(game);
        App.changeMenu("GameBoard");
    }
}
