package views;

import application.App;
import javafx.fxml.FXML;
import javafx.scene.effect.Bloom;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Lighting;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import models.GameNet;

import java.util.Objects;

public class ChangeAvatarController {

    @FXML
    private Text title;
    @FXML
    private Circle avatar1;
    @FXML
    private Circle avatar0;
    @FXML
    private Circle avatar2;
    @FXML
    private Circle avatar3;
    @FXML
    private Circle avatar4;

    private int selectedAvatar = GameNet.getCurrentUser().getAvatar();

    public void initialize(){
        title.setStyle("-fx-text-fill: #ffcc00");
        avatar0.setFill(new ImagePattern(new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/avatar0.jpeg")).toExternalForm())));
        avatar1.setFill(new ImagePattern(new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/avatar1.jpeg")).toExternalForm())));
        avatar2.setFill(new ImagePattern(new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/avatar2.jpeg")).toExternalForm())));
        avatar3.setFill(new ImagePattern(new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/avatar3.jpeg")).toExternalForm())));
        avatar4.setFill(new ImagePattern(new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/avatar4.jpeg")).toExternalForm())));

    }

    public void backButton(MouseEvent mouseEvent) {
        GameNet.getCurrentUser().setAvatar(selectedAvatar);
        App.changeMenu("ProfileMenu");

    }

    public void avatar0WasClicked(MouseEvent mouseEvent) {
        avatar0.setEffect(new Bloom());
        avatar1.setEffect(null);
        avatar2.setEffect(null);
        avatar3.setEffect(null);
        avatar4.setEffect(null);
        selectedAvatar = 0;
    }

    public void avatar1WasClicked(MouseEvent mouseEvent) {
        avatar0.setEffect(null);
        avatar1.setEffect(new Bloom());
        avatar2.setEffect(null);
        avatar3.setEffect(null);
        avatar4.setEffect(null);
        selectedAvatar = 1;
    }

    public void avatar2WasClicked(MouseEvent mouseEvent) {
        avatar0.setEffect(null);
        avatar1.setEffect(null);
        avatar2.setEffect(new Bloom());
        avatar3.setEffect(null);
        avatar4.setEffect(null);
        selectedAvatar = 2;
    }

    public void avatar3WasClicked(MouseEvent mouseEvent) {
        avatar0.setEffect(null);
        avatar1.setEffect(null);
        avatar2.setEffect(null);
        avatar3.setEffect(new Bloom());
        avatar4.setEffect(null);
        selectedAvatar = 3;
    }

    public void avatar4WasClicked(MouseEvent mouseEvent) {
        avatar0.setEffect(null);
        avatar1.setEffect(null);
        avatar2.setEffect(null);
        avatar3.setEffect(null);
        avatar4.setEffect(new Bloom());
        selectedAvatar = 4;
    }
}
