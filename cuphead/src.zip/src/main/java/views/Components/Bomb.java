package views.Components;

import controllers.GameController;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.util.Objects;

public class Bomb extends Rectangle {
    private boolean exploded;
    private boolean hurtTheEnemy;

    public Bomb(double x, double y){
        super(x, y, 40, 40);

        Image image = new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/bomb.png")).toExternalForm());

        this.setFill(GameController.checkForGrayscaleOfImage(image));

    }

    public boolean isExploded() {
        return exploded;
    }

    public void setExploded(boolean exploded) {
        this.exploded = exploded;
    }

    public void setImagePattern(ImagePattern imagePattern) {
        this.setFill(imagePattern);
    }

    public boolean isHurtTheEnemy() {
        return hurtTheEnemy;
    }

    public void setHurtTheEnemy(boolean hurtTheEnemy) {
        this.hurtTheEnemy = hurtTheEnemy;
    }
}
