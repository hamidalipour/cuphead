package views.Components;

import controllers.GameController;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.util.GregorianCalendar;
import java.util.Objects;

public class MiniBoss extends Rectangle {
    private int number;
    private double health = 2;
    private boolean exploded = false;

    public MiniBoss(boolean flyingAtTop, int number) {
        super(1280 + number * 150, 600, 100, 100);
        this.number = number;

        if (flyingAtTop){
          this.setY(50);
        }
        Image image;
        if (number == 4){
            image = new Image(
                    Objects.requireNonNull(getClass().getResource(
                            "/images/purple/1.png")).toExternalForm());
            ImagePattern imagePattern = GameController.checkForGrayscaleOfImage(image);
            this.setFill(imagePattern);
        } else {
            image = new Image(
                    Objects.requireNonNull(getClass().getResource(
                            "/images/yellow/1.png")).toExternalForm());
            ImagePattern imagePattern = GameController.checkForGrayscaleOfImage(image);
            this.setFill(imagePattern);
        }


    }

    public int getNumber() {
        return number;
    }

    public void setImagePattern(ImagePattern imagePattern) {
        this.setFill(imagePattern);
    }

    public double getHealth() {
        return health;
    }

    public boolean isExploded() {
        return exploded;
    }

    public void setHealth(double health) {
        this.health = health;
    }

    public void setExploded(boolean exploded) {
        this.exploded = exploded;
    }
}
