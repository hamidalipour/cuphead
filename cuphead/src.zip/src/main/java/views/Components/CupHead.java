package views.Components;

import Transitions.CupHeadMovingAnimation;
import controllers.GameController;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.util.Objects;

public class CupHead extends Rectangle {

    private ImagePattern imagePattern;
    private boolean movingDown = false;
    private boolean movingUp = false;
    private boolean movingRight = false;
    private boolean movingLeft = false;
    private boolean turned = false;
    private boolean firingUpperGun = true;
    private boolean exploded = false;

    public CupHead(){
        super(100, 400, 110, 100);

        Image image = new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/mugman_plane_idle_straight_0001.png")).toExternalForm());
        this.imagePattern = GameController.checkForGrayscaleOfImage(image);
        this.setFill(imagePattern);
    }

    public void goLeft(){
        if (this.getX() > 10) this.setX(this.getX() - 15);
        this.movingLeft = true;
        this.movingUp = false;
        this.movingDown = false;
        this.movingRight = false;
        this.turned = false;
    }

    public void goRight(){
        if (this.getX() < 1160) this.setX(this.getX() + 15);
        this.movingRight = true;
        this.movingUp = false;
        this.movingDown = false;
        this.movingLeft = false;
        this.turned = false;
    }

    public void goUp(){
        if (this.getY() > 10) this.setY(this.getY() - 15);
        this.movingUp = true;
        this.movingDown = false;
        this.movingRight = false;
        this.movingLeft = false;
    }

    public void goDown(){
        if (this.getY() < 610) this.setY(this.getY() + 15);
        this.movingUp = false;
        this.movingDown = true;
        this.movingLeft = false;
        this.movingRight = false;
    }

    public void setImagePattern(ImagePattern imagePattern) {
        this.imagePattern = imagePattern;
        this.setFill(imagePattern);
    }

    public boolean isMovingDown() {
        return movingDown;
    }

    public boolean isMovingUp() {
        return movingUp;
    }

    public void releaseUpDownKey(){
        movingDown = false;
        movingUp = false;
        movingLeft = false;
        movingRight = false;
        turned = false;
    }

    public boolean isTurned() {
        return turned;
    }

    public void setTurned(boolean turned) {
        this.turned = turned;
    }

    public boolean isFiringUpperGun() {
        return firingUpperGun;
    }

    public void setFiringUpperGun(boolean firingUpperGun) {
        this.firingUpperGun = firingUpperGun;
    }

    public boolean isMovingRight() {
        return movingRight;
    }

    public boolean isMovingLeft() {
        return movingLeft;
    }

    public boolean isExploded() {
        return exploded;
    }

    public void setExploded(boolean exploded) {
        this.exploded = exploded;
    }


}
