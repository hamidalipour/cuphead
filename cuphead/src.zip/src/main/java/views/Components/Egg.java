package views.Components;

import controllers.GameController;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.util.Objects;

public class Egg extends Rectangle {
    public Egg(double y){
        super(750, y, 100, 100);

        Image image = new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/egg.png")).toExternalForm());
        ImagePattern imagePattern = GameController.checkForGrayscaleOfImage(image);
        this.setFill(imagePattern);

    }
}
