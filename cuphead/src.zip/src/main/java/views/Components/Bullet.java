package views.Components;

import controllers.GameController;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.util.Objects;

public class Bullet extends Rectangle {
    private boolean exploded = false;
    private boolean hurtTheEnemy = false;

    public Bullet(double x, double y){
        super(x, y, 60, 20);

        Image image = new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/bullet.png")).toExternalForm());

        ImagePattern imagePattern = GameController.checkForGrayscaleOfImage(image);
        this.setFill(imagePattern);

    }

    public boolean isExploded() {
        return exploded;
    }

    public void setExploded(boolean exploded) {
        this.exploded = exploded;
    }

    public void setImagePattern(ImagePattern imagePattern) {
        this.setFill(imagePattern);
    }

    public boolean isHurtTheEnemy() {
        return hurtTheEnemy;
    }

    public void setHurtTheEnemy(boolean hurtTheEnemy) {
        this.hurtTheEnemy = hurtTheEnemy;
    }
}
