package views.Components;

import Transitions.BossMovingAnimation;
import controllers.GameController;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.util.Objects;

public class Boss extends Rectangle{
    private ImagePattern imagePattern;
    private boolean movingUp = true;
    private boolean isShooting = false;
    private boolean bulletReadyToBeShot = false;
    private boolean bulletWasShot = false;

    private double health = 300;
    private boolean exploded = false;

    public Boss(){
        super(750, 200, 500, 400);

        Image image = new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/BossFly/1.png")).toExternalForm());
        this.imagePattern = GameController.checkForGrayscaleOfImage(image);
        this.setFill(imagePattern);
    }

    public boolean isMovingUp() {
        return movingUp;
    }

    public boolean isShooting() {
        return isShooting;
    }

    public boolean isBulletReadyToBeShot() {
        return bulletReadyToBeShot;
    }

    public boolean isBulletWasShot() {
        return bulletWasShot;
    }

    public void setImagePattern(ImagePattern imagePattern) {
        this.imagePattern = imagePattern;
        this.setFill(imagePattern);
    }

    public void setMovingUp(boolean movingUp) {
        this.movingUp = movingUp;
    }

    public void setShooting(boolean shooting) {
        isShooting = shooting;
    }

    public void setBulletReadyToBeShot(boolean bulletReadyToBeShot) {
        this.bulletReadyToBeShot = bulletReadyToBeShot;
    }

    public double getHealth() {
        return health;
    }

    public boolean isExploded() {
        return exploded;
    }

    public void setHealth(double health) {
        this.health = health;
    }

    public void setExploded(boolean exploded) {
        this.exploded = exploded;
    }

    public void setBulletWasShot(boolean bulletWasShot) {
        this.bulletWasShot = bulletWasShot;
    }
}
