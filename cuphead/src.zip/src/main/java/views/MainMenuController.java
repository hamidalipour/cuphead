package views;

import application.App;
import javafx.scene.input.MouseEvent;
import models.Game;
import models.GameNet;

public class MainMenuController {
    public void startGame(MouseEvent mouseEvent){
        Game game = new Game(GameNet.getGameLevel());
        GameNet.setCurrentGame(game);
        App.changeMenu("GameBoard");
    }

    public void goToProfileMenu(MouseEvent mouseEvent) {
        App.changeMenu("ProfileMenu");
    }

    public void goToScoreboard(MouseEvent mouseEvent) {
        App.changeMenu("Scoreboard");
    }

    public void goToSetting(MouseEvent mouseEvent) {
        App.changeMenu("Setting");
    }

    public void exitMenu(MouseEvent mouseEvent) {
        GameNet.setCurrentUser(null);
        App.changeMenu("FirstPage");
    }

    public void goToMainMenu(MouseEvent mouseEvent) {
        App.changeMenu("MainMenu");
    }
}
