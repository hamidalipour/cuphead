package views;

import Transitions.*;
import controllers.GameController;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.ParallelTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;
import models.Game;
import models.GameNet;
import views.Components.Bomb;
import views.Components.Boss;
import views.Components.Bullet;
import views.Components.CupHead;

import java.util.Objects;

public class GameBoardController {


    public AnchorPane pane;
    private Boss boss;
    private CupHead cupHead;
    private Text time;
    private Text cupHeadSore;
    private Text cupHeadHealth;
    private Text bossHealth;
    private ProgressBar bossHealthProgressBar;
    @FXML
    private ImageView background1;
    @FXML
    private ImageView background2;

    @FXML
    public void initialize() {
        if (!GameNet.isMute()){
            GameNet.getMenuMusic().stop();
            GameNet.getGameMusic().play();
        }

        setBackgroundTransition();
        boss = new Boss();
        pane.getChildren().add(boss);
        BossMovingAnimation bossMovingAnimation = new BossMovingAnimation(boss, pane);
        bossMovingAnimation.play();
        GameNet.getCurrentGame().getGameTransitions().add(bossMovingAnimation);
        this.cupHead = createCupHead(pane);
        pane.getChildren().add(cupHead);
        CupHeadMovingAnimation cupHeadMovingAnimation = new CupHeadMovingAnimation(cupHead, pane);
        cupHeadMovingAnimation.play();
        GameNet.getCurrentGame().getGameTransitions().add(cupHeadMovingAnimation);

        BossAttackTimeline bossAttackTimeline = new BossAttackTimeline(pane, boss);
        bossAttackTimeline.play();
        GameNet.getCurrentGame().getGameTransitions().add(bossAttackTimeline);

        statisticsInitialization();


    }

    public void statisticsInitialization(){
        time = new Text("0:0:0");
        time.setLayoutX(600);
        time.setLayoutY(35);
        time.setStyle("-fx-font-size: 20");
        pane.getChildren().add(time);

        cupHeadSore = new Text("score: " + GameNet.getCurrentGame().getScore());
        cupHeadSore.setLayoutX(0);
        cupHeadSore.setLayoutY(35);
        cupHeadSore.setStyle("-fx-font-size: 20");
        pane.getChildren().add(cupHeadSore);

        cupHeadHealth = new Text("lives: " + GameNet.getCurrentGame().getHealth());
        cupHeadHealth.setLayoutX(120);
        cupHeadHealth.setLayoutY(35);
        cupHeadHealth.setStyle("-fx-font-size: 20");
        pane.getChildren().add(cupHeadHealth);

        bossHealth = new Text("boss lives: " + boss.getHealth());
        bossHealth.setLayoutX(1110);
        bossHealth.setLayoutY(35);
        bossHealth.setStyle("-fx-font-size: 20");
        pane.getChildren().add(bossHealth);

        bossHealthProgressBar = new ProgressBar();
        bossHealthProgressBar.setLayoutX(900);
        bossHealthProgressBar.setLayoutY(10);
        bossHealthProgressBar.setPrefWidth(200);
        bossHealthProgressBar.setPrefHeight(30);
        bossHealthProgressBar.setProgress(100);
        bossHealthProgressBar.setStyle("-fx-accent: green");
        pane.getChildren().add(bossHealthProgressBar);

        GameStatistic gameStatistic = new GameStatistic(boss, cupHead, time, cupHeadSore, cupHeadHealth, bossHealth, bossHealthProgressBar);
        gameStatistic.play();
        GameNet.getCurrentGame().getGameTransitions().add(gameStatistic);
    }

    public static CupHead createCupHead(AnchorPane anchorPane){
        CupHead cupHead = new CupHead();

        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                cupHead.requestFocus();
            }
        });
        cupHead.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                switch (keyEvent.getCode().getName()){
                    case "Left":
                        cupHead.goLeft();
                        break;
                    case "Right":
                        cupHead.goRight();
                        break;
                    case "Up":
                        cupHead.goUp();
                        break;
                    case "Down":
                        cupHead.goDown();
                        break;
                    case "Space":
                        if (GameNet.getCurrentGame().isShootingBullet())
                            generateBullet(cupHead, anchorPane);
                         else generateBomb(cupHead, anchorPane);
                        checkMovementButtonsBeingPushed(cupHead);
                        break;
                    case "Tab":
                        if (GameNet.getCurrentGame().isShootingBullet()){
                            GameNet.getCurrentGame().setShootingBullet(false);
                        } else GameNet.getCurrentGame().setShootingBullet(true);
                        checkMovementButtonsBeingPushed(cupHead);
                        break;
                }
            }
        });

        cupHead.setOnKeyReleased(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                switch (keyEvent.getCode().getName()){
                    case "Up":
                    case "Down":
                    case "Right":
                    case "Left":
                        cupHead.releaseUpDownKey();
                        break;
                }
            }
        });

        return cupHead;
    }

    public void setBackgroundTransition(){
        background1.setFitHeight(720);
        background2.setFitHeight(720);
        background1.setFitWidth(1280);
        background2.setFitWidth(1280);

        Image image = new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/game_background.png")).toExternalForm());
        if (GameNet.isGrayscale()){
            background1.setImage(GameController.convertImageToGrayscale(image));
            background2.setImage(GameController.convertImageToGrayscale(image));
        } else {
            background1.setImage(image);
            background2.setImage(image);
        }

        TranslateTransition translateTransition =
                new TranslateTransition(Duration.millis(20000), background1);
        translateTransition.setFromX(0);
        translateTransition.setToX(-1280);
        translateTransition.setInterpolator(Interpolator.LINEAR);

        TranslateTransition translateTransition2 =
                new TranslateTransition(Duration.millis(20000), background2);
        translateTransition2.setFromX(0);
        translateTransition2.setToX(-1280);
        translateTransition2.setInterpolator(Interpolator.LINEAR);

        ParallelTransition parallelTransition = new ParallelTransition(translateTransition, translateTransition2);
        parallelTransition.setCycleCount(Animation.INDEFINITE);
        parallelTransition.play();
        GameNet.getCurrentGame().getGameTransitions().add(parallelTransition);
    }

    public static void generateBullet(CupHead cupHead, AnchorPane anchorPane){
        Bullet bullet;
        if (cupHead.isFiringUpperGun()){
            bullet = new Bullet(cupHead.getX() + 90, cupHead.getY() + 30);
            cupHead.setFiringUpperGun(false);
        } else {
            bullet = new Bullet(cupHead.getX() + 90, cupHead.getY() + 70);
            cupHead.setFiringUpperGun(true);
        }

        BulletAnimation bulletAnimation = new BulletAnimation(bullet, anchorPane);
        bulletAnimation.play();

        if (!GameNet.isMute()) GameNet.getFiringSound().play();

        GameNet.getCurrentGame().getGameTransitions().add(bulletAnimation);
        anchorPane.getChildren().add(bullet);
    }

    public static void generateBomb(CupHead cupHead, AnchorPane anchorPane){
        Bomb bomb = new Bomb(cupHead.getX() + 60, cupHead.getY() + 80);
            cupHead.setFiringUpperGun(false);


        BombAnimation bombAnimation = new BombAnimation(bomb, anchorPane);
        bombAnimation.play();

        if (!GameNet.isMute()) GameNet.getFiringSound().play();

        GameNet.getCurrentGame().getGameTransitions().add(bombAnimation);
        anchorPane.getChildren().add(bomb);
    }

    public static void checkMovementButtonsBeingPushed(CupHead cupHead){
        if (cupHead.isMovingUp()) cupHead.goUp();
        else if (cupHead.isMovingDown()) cupHead.goDown();
        else if (cupHead.isMovingRight()) cupHead.goRight();
        else if (cupHead.isMovingLeft()) cupHead.goLeft();
    }
}
