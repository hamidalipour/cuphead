package views;

import application.App;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import models.GameNet;

public class SettingController {

    private ChoiceBox gameDifficulty;
    private ChoiceBox gameColor;
    private ChoiceBox sound;


    @FXML
    private AnchorPane settingAnchorPane;

    public void initialize(){
        Text gameDifficultyText = new Text("game difficulty");
        gameDifficultyText.setLayoutX(580);
        gameDifficultyText.setLayoutY(390);
        gameDifficultyText.setStyle("-fx-font-size: 20");
        gameDifficultyText.setFill(Color.RED);

        String[] levels = { "level 1", "level 2", "level 3" };

        gameDifficulty = new ChoiceBox(FXCollections.observableArrayList(levels));
        gameDifficulty.setLayoutX(550);
        gameDifficulty.setLayoutY(400);
        gameDifficulty.setPrefWidth(180);
        gameDifficulty.setValue(levels[GameNet.getGameLevel() - 1]);

        Text musicText = new Text("music");
        musicText.setLayoutX(580);
        musicText.setLayoutY(470);
        musicText.setStyle("-fx-font-size: 20");
        musicText.setFill(Color.RED);

        String[] musicOptions = { "playing", "muted" };

        sound = new ChoiceBox(FXCollections.observableArrayList(musicOptions));
        sound.setLayoutX(550);
        sound.setLayoutY(480);
        sound.setPrefWidth(180);
        if (!GameNet.isMute())
            sound.setValue("playing");
        else sound.setValue("muted");

        String[] colorOptions = { "colored", "grayscale" };

        gameColor = new ChoiceBox(FXCollections.observableArrayList(colorOptions));
        gameColor.setLayoutX(550);
        gameColor.setLayoutY(540);
        gameColor.setPrefWidth(180);
        if (!GameNet.isGrayscale())
            gameColor.setValue("colored");
        else gameColor.setValue("grayscale");



        settingAnchorPane.getChildren().add(gameDifficultyText);
        settingAnchorPane.getChildren().add(gameDifficulty);
        settingAnchorPane.getChildren().add(musicText);
        settingAnchorPane.getChildren().add(sound);
        settingAnchorPane.getChildren().add(gameColor);
    }


    public void goToMainMenu(MouseEvent mouseEvent) {
        switch (gameDifficulty.getValue().toString()){
            case "level 1":
                GameNet.setGameLevel(1);
                break;
            case "level 2":
                GameNet.setGameLevel(2);
                break;
            case "level 3":
                GameNet.setGameLevel(3);
                break;
        }

        switch (sound.getValue().toString()){
            case "playing":
                GameNet.setMute(false);
                if (!GameNet.getMenuMusic().isPlaying())
                    GameNet.getMenuMusic().play();
                break;
            case "muted":
                GameNet.setMute(true);
                if (GameNet.getMenuMusic().isPlaying())
                    GameNet.getMenuMusic().stop();
                break;
        }

        switch (gameColor.getValue().toString()){
            case "colored":
                GameNet.setGrayscale(false);
                break;
            case "grayscale":
                GameNet.setGrayscale(true);
                break;
        }

        App.changeMenu("MainMenu");
    }
}
