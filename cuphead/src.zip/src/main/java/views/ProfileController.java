package views;

import application.App;
import controllers.MenuController;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import models.GameNet;

import java.util.Objects;

public class ProfileController {

    @FXML
    private Button deleteAccountButton;
    @FXML
    private Text upperText;
    @FXML
    private Text downerText;
    @FXML
    private TextField newPasswordTextField;
    @FXML
    private TextField newUsernameTextField;
    @FXML
    private Button changeUsernameOrPasswordButton;
    @FXML
    private TextField currentPasswordTextField;
    @FXML
    private Button changeUsernameButton;
    @FXML
    private Button changeAvatarButton;
    @FXML
    private Button changePasswordButton;
    @FXML
    private Text username;
    @FXML
    private Text score;
    @FXML
    private Circle userAvatar;

    public void initialize(){
        ImagePattern imagePattern = new ImagePattern(new Image(
                Objects.requireNonNull(getClass().getResource(
                        "/images/avatar" + GameNet.getCurrentUser().getAvatar() + ".jpeg")).toExternalForm()));
        userAvatar.setFill(imagePattern);
        username.setText(GameNet.getCurrentUser().getUsername());
        score.setText("score: " + GameNet.getCurrentUser().getPoint());
        changeUsernameOrPasswordButton.setVisible(false);
        currentPasswordTextField.setVisible(false);
        newPasswordTextField.setVisible(false);
        newUsernameTextField.setVisible(false);
    }

    public void backButton(MouseEvent mouseEvent) {
        back();
    }

    public void back(){
        if (currentPasswordTextField.isVisible()){
            deleteAccountButton.setVisible(true);
            changeUsernameButton.setVisible(true);
            changePasswordButton.setVisible(true);
            changeAvatarButton.setVisible(true);
            currentPasswordTextField.setVisible(false);
            currentPasswordTextField.setText("");
            newUsernameTextField.setVisible(false);
            newUsernameTextField.setText("");
            newPasswordTextField.setVisible(false);
            newPasswordTextField.setText("");
            changeUsernameOrPasswordButton.setVisible(false);
            upperText.setText("");
            downerText.setText("");
            currentPasswordTextField.setStyle("-fx-border-color: black");
            newPasswordTextField.setStyle("-fx-border-color: black");
            newUsernameTextField.setStyle("-fx-border-color: black");
        }else App.changeMenu("MainMenu");
    }

    public void changeUsername(MouseEvent mouseEvent) {
        deleteAccountButton.setVisible(false);
        changeUsernameButton.setVisible(false);
        changePasswordButton.setVisible(false);
        changeAvatarButton.setVisible(false);
        currentPasswordTextField.setVisible(true);
        newUsernameTextField.setVisible(true);
        changeUsernameOrPasswordButton.setVisible(true);
        
    }

    public void changePassword(MouseEvent mouseEvent) {
        deleteAccountButton.setVisible(false);
        changeUsernameButton.setVisible(false);
        changePasswordButton.setVisible(false);
        changeAvatarButton.setVisible(false);
        currentPasswordTextField.setVisible(true);
        newPasswordTextField.setVisible(true);
        changeUsernameOrPasswordButton.setVisible(true);
    }

    public void changeUsernameOrPassword(MouseEvent mouseEvent) {
        if (!GameNet.getCurrentUser().getPassword().equals(currentPasswordTextField.getText())){
            upperText.setText("incorrect password");
            downerText.setText("");
            currentPasswordTextField.setStyle("-fx-border-color: red");
            newPasswordTextField.setStyle("-fx-border-color: black");
            newUsernameTextField.setStyle("-fx-border-color: black");
        } else{
            if (newPasswordTextField.isVisible()){
                if (MenuController.passwordIsWeak(newPasswordTextField.getText())){
                    upperText.setText("");
                    downerText.setText("password is weak");
                    newPasswordTextField.setStyle("-fx-border-color: red");
                    currentPasswordTextField.setStyle("-fx-border-color: black");
                } else {
                    GameNet.getCurrentUser().setPassword(newPasswordTextField.getText());
                    back();
                }
            } else {
                if (GameNet.getUserByUsername(newUsernameTextField.getText()) != null){
                    upperText.setText("");
                    downerText.setText("please enter a new username");
                    newUsernameTextField.setStyle("-fx-border-color: red");
                    currentPasswordTextField.setStyle("-fx-border-color: black");
                } else {
                    GameNet.getCurrentUser().setUsername(newUsernameTextField.getText());
                    username.setText(GameNet.getCurrentUser().getUsername());
                    back();
                }
            }
        }
    }

    public void changeAvatar(MouseEvent mouseEvent) {
        App.changeMenu("ChangeAvatarMenu");
    }

    public void deleteAccount(MouseEvent mouseEvent) {
        GameNet.getUsers().remove(GameNet.getCurrentUser());
        App.changeMenu("FirstPage");
    }
}
