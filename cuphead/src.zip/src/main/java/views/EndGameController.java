package views;

import application.App;
import javafx.animation.Transition;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import models.Game;
import models.GameNet;

import java.util.Objects;

public class EndGameController {

    @FXML
    private Button retryButton;
    @FXML
    private Button quitButton;
    @FXML
    private Text score;
    @FXML
    private Text gameDuration;
    @FXML
    private AnchorPane endGameScene;

    public void initialize(){
        if (!GameNet.isMute()){
            GameNet.getMenuMusic().play();
            GameNet.getGameMusic().stop();
        }

        stopPreviousGameTransitions();

        if (GameNet.getCurrentUser() != null)
            GameNet.getCurrentUser().setPoint(GameNet.getCurrentUser().getPoint() + GameNet.getCurrentGame().getScore());



        if (GameNet.getCurrentGame().getHealth() <= 0){
            BackgroundImage myBI= new BackgroundImage(new Image(Objects.requireNonNull(getClass().getResource("/images/defeat.png")).toExternalForm()),
                    BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                    BackgroundSize.DEFAULT);

            endGameScene.setBackground(new Background(myBI));


        } else {

            BackgroundImage myBI= new BackgroundImage(new Image(Objects.requireNonNull(getClass().getResource("/images/victory.jpeg")).toExternalForm()),
                    BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                    BackgroundSize.DEFAULT);

            endGameScene.setBackground(new Background(myBI));
        }

        score.setText("score: " + GameNet.getCurrentGame().getScore());
        score.setStyle("-fx-font-size: 30");
        score.setFill(Color.WHITE);

        gameDuration.setText("game duration: " + GameNet.getCurrentGame().getHour() + ":" +
                GameNet.getCurrentGame().getMinute() + ":" + GameNet.getCurrentGame().getSecond());
        gameDuration.setStyle("-fx-font-size: 30");
        gameDuration.setFill(Color.WHITE);
    }

    public void stopPreviousGameTransitions(){
        for (Transition gameTransition : GameNet.getCurrentGame().getGameTransitions()) {
            gameTransition.stop();
        }
    }

    public void retryGame(MouseEvent mouseEvent) {
        GameNet.setCurrentGame(new Game(GameNet.getGameLevel()));
        App.changeMenu("GameBoard");
    }

    public void quitGame(MouseEvent mouseEvent) {
        GameNet.setCurrentGame(null);
        if (GameNet.getCurrentUser() == null)
            App.changeMenu("FirstPage");
        else App.changeMenu("MainMenu");
    }
}

