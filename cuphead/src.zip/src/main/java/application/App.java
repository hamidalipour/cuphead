package application;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import models.GameNet;
import views.Components.CupHead;

import java.io.IOException;
import java.net.URL;

public class App extends Application {
    private static Scene scene;
    public static void main(String[] args) throws IOException {
        GameNet.readAllUsers();
        GameNet.initializeMusics();
        launch();
        GameNet.saveAllUsers();
    }

    @Override
    public void start(Stage stage) throws Exception {

        Parent root = loadFXML("FirstPage");
        Scene scene = new Scene(root);
        App.scene = scene;
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }

    public static void changeMenu(String name){

        Parent root = loadFXML(name);
        App.scene.setRoot(root);

    }
    private static Parent loadFXML(String name){
        try {
            URL address = new URL(App.class.getResource("/fxml/" + name + ".fxml").toString());
            return FXMLLoader.load(address);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}