module com.example.cuphead {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires javafx.media;


    exports application;
    exports views;
    opens application to javafx.fxml;
    opens views to javafx.fxml;
    opens models to com.google.gson;
}