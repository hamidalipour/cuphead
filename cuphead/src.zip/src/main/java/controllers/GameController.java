package controllers;

import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import models.GameNet;
import views.Components.Boss;

public class GameController {
    public static boolean haveCollision(Rectangle rectangle1, Rectangle rectangle2){
        double x1, y1, width1, height1, x2, y2, width2, height2;
        x1 = rectangle1.getX();
        y1 = rectangle1.getY();
        width1 = rectangle1.getWidth();
        height1 = rectangle1.getHeight();

        x2 = rectangle2.getX();
        y2 = rectangle2.getY();
        width2 = rectangle2.getWidth();
        height2 = rectangle2.getHeight();


        if (rectangle2 instanceof Boss){
            x2 = rectangle2.getX() + 50;
            y2 = rectangle2.getY() + 50;
            width2 = rectangle2.getWidth() - 50;
            height2 = rectangle2.getHeight() - 100;
        }
        return x1 < x2 + width2 &&
                x1 + width1 > x2 &&
                y1 < y2 + height2 &&
                y1 + height1 > y2;
    }

    public static WritableImage blinkImage(Image image) {
        PixelReader pReader = image.getPixelReader();
        WritableImage wImage = new WritableImage((int) image.getWidth(), (int) image.getHeight());
        PixelWriter pWriter = wImage.getPixelWriter();
        for (int i = 0; i < wImage.getHeight(); i++) {
            for (int j = 0; j < image.getWidth(); j++) {
                Color color = pReader.getColor(j, i);
                if (color.getOpacity() != 0)
                    pWriter.setColor(j, i, Color.WHITE);
            }
        }
        return wImage;
    }

    public static WritableImage convertImageToGrayscale(Image image) {
        PixelReader pReader = image.getPixelReader();
        WritableImage wImage = new WritableImage((int) image.getWidth(), (int) image.getHeight());
        PixelWriter pWriter = wImage.getPixelWriter();
        for (int i = 0; i < wImage.getHeight(); i++) {
            for (int j = 0; j < image.getWidth(); j++) {
                Color color = pReader.getColor(j, i);
                if (color.getOpacity() != 0)
                    pWriter.setColor(j, i, color.grayscale());
            }
        }
        return wImage;
    }

    public static ImagePattern checkForGrayscaleOfImage(Image image){
        if (GameNet.isGrayscale()){
            WritableImage writableImage = convertImageToGrayscale(image);
            return new ImagePattern(writableImage);
        } else return new ImagePattern(image);
    }


}
