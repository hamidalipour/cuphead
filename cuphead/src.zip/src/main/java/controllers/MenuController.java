package controllers;

public class MenuController {
    public static boolean passwordIsWeak(String password){
        if (password.length() < 8) return true;
        return false;
    }
}
